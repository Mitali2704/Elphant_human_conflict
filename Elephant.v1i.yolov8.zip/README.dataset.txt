# Elephant > 2025-03-08 12:22am
https://universe.roboflow.com/aa-zjshm/elephant-u38il

Provided by a Roboflow user
License: CC BY 4.0

